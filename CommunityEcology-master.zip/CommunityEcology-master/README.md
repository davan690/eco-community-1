# CommunityEcology
# To simulate data under community assembly models and then perform model selection use the below scripts. The scripts can simulate regional phylogenetic trees and then be used to simulate 6 community assembly models, using those regional trees. BM = Brownian Motion and Ornstein-Uhlenbeck. neut = neutral, hf=habitat filtering, and ce = competitive exclusion. 
